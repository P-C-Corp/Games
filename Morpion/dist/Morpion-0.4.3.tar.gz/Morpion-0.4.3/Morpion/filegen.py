import json

while True:
    text = input()
    with open(r'C:\Users\mathe\Documents\code\Projets\Games\Morpion\Morpion\test.json', 'w', encoding='utf-8') as output:
        json.dump(text, output)
    print('ok')